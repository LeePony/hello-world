ECharts
=======
http://echarts.baidu.com

基于Canvas，纯Javascript图表库，提供直观，生动，可交互，可个性化定制的数据可视化图表。创新的拖拽重计算、数据视图、值域漫游等特性大大增强了用户体验，赋予了用户对数据进行挖掘、整合的能力。

**———— 大数据时代，重新定义数据图表的时候到了**

LICENSE:
https://github.com/ecomfe/echarts/blob/master/LICENSE.txt
 
Extension
------------
ECharts扩展，extension下每一个文件夹为一个独立扩展，一个完整的扩展至少包含源码、例子、可直接引入的单文件（amd模块化或者script标签式引入）

+ extension
	+  snsShare
		+  src
		+  build
		+  doc
			+  doc.html
			+  example.html
 

