define({
	xxx:"中文"
});